# OSN Assignment 5 ( Multithreading and Networking )
# Name: Abhinav Reddy Boddu
# Roll No: 2021101034
# File Structure:
```
2021101034
├── q1
│   ├── q1.c
│   └── README.md
├── q2
│   ├── q2.c
│   ├── q2CleanCode.txt
│   └── README.md
├── q3
│   ├── client.cpp
│   ├── README.md
│   └── server.cpp
└── README.md
```